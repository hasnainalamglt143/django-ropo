import { Token } from '../parse/cst';
import { ComposeErrorHandler } from './composer';
export declare function flowIndentCheck(indent: number, fc: Token | null | undefined, onError: ComposeErrorHandler): void;
