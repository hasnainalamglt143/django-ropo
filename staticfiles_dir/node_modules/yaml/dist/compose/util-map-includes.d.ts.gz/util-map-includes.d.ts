import type { ParsedNode } from '../nodes/Node.js';
import type { Pair } from '../nodes/Pair.js';
import type { ComposeContext } from './compose-node.js';
export declare function mapIncludes(ctx: ComposeContext, items: Pair<ParsedNode>[], search: ParsedNode): boolean;
