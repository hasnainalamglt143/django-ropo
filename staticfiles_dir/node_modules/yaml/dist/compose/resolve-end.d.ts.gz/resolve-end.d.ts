import type { SourceToken } from '../parse/cst.js';
import type { ComposeErrorHandler } from './composer.js';
export declare function resolveEnd(end: SourceToken[] | undefined, offset: number, reqSpace: boolean, onError: ComposeErrorHandler): {
    comment: string;
    offset: number;
};
