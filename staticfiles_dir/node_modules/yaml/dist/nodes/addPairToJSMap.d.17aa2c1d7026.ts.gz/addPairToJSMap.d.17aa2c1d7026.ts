import type { Pair } from './Pair.js';
import { ToJSContext } from './toJS.js';
import type { MapLike } from './YAMLMap.js';
export declare function addPairToJSMap(ctx: ToJSContext | undefined, map: MapLike, { key, value }: Pair): MapLike;
