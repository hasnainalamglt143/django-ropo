import type { Document } from '../doc/Document.js';
import type { Node } from '../nodes/Node.js';
import type { ToStringOptions } from '../options.js';
export declare function stringifyDocument(doc: Readonly<Document<Node, boolean>>, options: ToStringOptions): string;
