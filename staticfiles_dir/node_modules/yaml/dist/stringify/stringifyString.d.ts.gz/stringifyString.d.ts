import { Scalar } from '../nodes/Scalar.js';
import type { StringifyContext } from './stringify.js';
interface StringifyScalar {
    value: string;
    comment?: string | null;
    type?: string;
}
export declare function stringifyString(item: Scalar | StringifyScalar, ctx: StringifyContext, onComment?: () => void, onChompKeep?: () => void): string;
export {};
