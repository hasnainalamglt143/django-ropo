/// <reference types="node" resolution-mode="require"/>
/// <reference types="node" resolution-mode="require"/>
export declare const readdirOrError: (path: string) => Promise<import("fs").Dirent[] | NodeJS.ErrnoException>;
export declare const readdirOrErrorSync: (path: string) => import("fs").Dirent[] | NodeJS.ErrnoException;
//# sourceMappingURL=readdir-or-error.d.ts.map