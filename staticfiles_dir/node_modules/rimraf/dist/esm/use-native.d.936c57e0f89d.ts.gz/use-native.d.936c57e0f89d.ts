import { RimrafAsyncOptions, RimrafOptions } from './index.js';
export declare const useNative: (opt?: RimrafAsyncOptions) => boolean;
export declare const useNativeSync: (opt?: RimrafOptions) => boolean;
//# sourceMappingURL=use-native.d.ts.map