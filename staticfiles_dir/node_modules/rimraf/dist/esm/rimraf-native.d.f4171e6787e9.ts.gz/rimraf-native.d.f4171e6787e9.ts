import { RimrafAsyncOptions, RimrafSyncOptions } from './index.js';
export declare const rimrafNative: (path: string, opt: RimrafAsyncOptions) => Promise<boolean>;
export declare const rimrafNativeSync: (path: string, opt: RimrafSyncOptions) => boolean;
//# sourceMappingURL=rimraf-native.d.ts.map