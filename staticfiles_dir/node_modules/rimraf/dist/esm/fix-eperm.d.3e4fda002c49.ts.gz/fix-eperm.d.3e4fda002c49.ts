export declare const fixEPERM: (fn: (path: string) => Promise<any>) => (path: string) => Promise<any>;
export declare const fixEPERMSync: (fn: (path: string) => any) => (path: string) => any;
//# sourceMappingURL=fix-eperm.d.ts.map