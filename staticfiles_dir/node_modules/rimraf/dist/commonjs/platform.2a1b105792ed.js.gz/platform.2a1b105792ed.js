"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = process.env.__TESTING_RIMRAF_PLATFORM__ || process.platform;
//# sourceMappingURL=platform.js.114e3ab90a67.map