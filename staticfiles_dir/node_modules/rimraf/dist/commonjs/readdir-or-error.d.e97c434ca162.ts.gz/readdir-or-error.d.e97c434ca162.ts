/// <reference types="node" />
/// <reference types="node" />
export declare const readdirOrError: (path: string) => Promise<import("fs").Dirent[] | NodeJS.ErrnoException>;
export declare const readdirOrErrorSync: (path: string) => import("fs").Dirent[] | NodeJS.ErrnoException;
//# sourceMappingURL=readdir-or-error.d.ts.map