"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = process.env.__TESTING_RIMRAF_PLATFORM__ || process.platform;
//# sourceMappingURL=platform.js.map