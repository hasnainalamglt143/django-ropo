export declare const ignoreENOENT: (p: Promise<any>) => Promise<any>;
export declare const ignoreENOENTSync: (fn: () => any) => any;
//# sourceMappingURL=ignore-enoent.d.ts.map