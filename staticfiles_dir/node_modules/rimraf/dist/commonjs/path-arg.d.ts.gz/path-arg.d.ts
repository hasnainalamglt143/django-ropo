import { RimrafAsyncOptions } from './index.js';
declare const pathArg: (path: string, opt?: RimrafAsyncOptions) => string;
export default pathArg;
//# sourceMappingURL=path-arg.d.ts.map