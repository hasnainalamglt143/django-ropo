export declare const defaultTmp: (path: string) => Promise<string>;
export declare const defaultTmpSync: (path: string) => string;
//# sourceMappingURL=default-tmp.d.ts.map